
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
public class ServerIndexData{

 Double rs;
 List<BigInteger>pos;
 String inverse;
 public ServerIndexData()
 {

    rs = new Double(-1.0);
    inverse = "";
    pos = new ArrayList<BigInteger>();
 }

 public ServerIndexData(String a)
 {
     rs = 1.0;
     inverse = new String(a);
     //pos = l;
 }
 public ServerIndexData(double a)
 {
     rs = new Double(a);
     //pos = l;
 }
 public ServerIndexData(double a, List<BigInteger> l)
 {
     rs = new Double(a);
     pos = l;
 }

 public void PrintData(BigInteger _secretPrime)
 {
     System.out.print("rs = "+ rs.intValue());
     System.out.print(",  list :  <");
     if(inverse != null)
     {
        System.out.print(", "+ inverse.toString());
     }
     if(pos != null)
     {
     for(int i = 0;i < pos.size();i++)
     {
         System.out.print(", "+ pos.get(i).toString());

     }
     }
     System.out.print(">\n");
     
     return ;
 }
}
