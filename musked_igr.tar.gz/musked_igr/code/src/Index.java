
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.*;
import java.math.*;
import java.security.SecureRandom;
import java.math.BigInteger;
//import org.bouncycastle.crypto.engines.AESEngine;
//import org.apache.commons.lang.WordUtils;

//This class is used to generate a client index table when we have the keywords stored in a .txt file

public class Index {
    private int MAX_WORD_FRQ;
	private ArrayList<String[]> strings;
    private BigInteger _secretPrime;	
	private int NOF;
    public Index(BigInteger p, int nof)
    {
        //_secretPrime = new BigInteger("228199");
       // SecureRandom r = new SecureRandom();
        //_secretPrime = BigInteger.probablePrime(512,r);
        //System.out.println("first time the prime is :   " + _secretPrime.toString());
        _secretPrime = new BigInteger(p.toString());
        MAX_WORD_FRQ = 10;
        NOF = nof;
    }
    
    
    public BigInteger inverse (BigInteger A)
	{
		BigInteger c= new BigInteger("-1");
		//BigInteger b= new BigInteger("228199");
		//BigInteger C =A.modPow(c,b);
		BigInteger C =A.modPow(c,_secretPrime);
		//
        return C;
	}

    
	
	public void IndexGen(
     //String[] A,                                                     // list of ordered keywords
     //int B,                                                          // number of documents to be searched
     //int[] C,                                                        // Decimal(AES(word)) array
     List<List<String>> wordList,                                            // client index
     HashMap<String,String> phoneList,                                            // client index
     List<HashMap<String,ServerIndexData>> server_ind_new,                     // server index
     List<HashMap<String,ServerIndexData>> server_data,                     // server index
     //BigInteger spme,
    String key,
    String IV,
    String key_s
    )
      throws IOException
        {
            //spme = new BigInteger(_secretPrime.toString());
            HashMap<String,BigInteger> phoneMuskList = new HashMap<String,BigInteger>();
		String ind="";
		//List<String[]> list=new ArrayList<String[]>();/////////////////////////////////////////This is the client index
		ArrayList<String[]> templist=new ArrayList<String[]>();
	//	List<Integer> list1 = new ArrayList<Integer>(Collections.nCopies(150000, 0));
		//List<Integer>F_d=new ArrayList<Integer>();
		//List<Integer>F_t=new ArrayList<Integer>();
		//int numb=0;
	

        HashMap<String,BigInteger> sudonamelist = new HashMap<String,BigInteger>();
        //
		Integer n = new Integer(100); 
		List<List<Integer>> ls2d = new ArrayList<List<Integer>>();
		
		//List<List<Double>> server_ind = new ArrayList<List<Double>>();///////////////////////////////This is server index
		
        //List<List<ServerIndexData>> server_ind_new = new ArrayList<List<ServerIndexData>>();///////////////////////////////This is server index
		
		
		List<Double>x1=new ArrayList<Double>();
		
		List<Integer> x = new ArrayList<Integer>();
		
        
   /////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Client index generation
   // This is used to calculate the inverse of all the numbers stored in the array and store it in a 2d array
        try{

		Encryption encryp=new Encryption();
   
        BufferedReader in = new BufferedReader(new FileReader("/home//indranil//Desktop/words.txt"));
        //BufferedReader in = new BufferedReader(new FileReader("/home//indranil//IntelligentVoice//data//words.txt"));
		String line;
        BigInteger one =new BigInteger(new String("1"));
        BigInteger ix =new BigInteger(new String("2"));
        int sudonam = 1;
		while((line = in.readLine()) != null)
		{

            // creating englist word list that maps to phone words
			String[] arr=line.split(" ");
            List<String> tmpl =new ArrayList<String>(Arrays.asList(arr)); 
			wordList.add(tmpl);
            
            // creating phone word list that maps to client index
            for(int ipl = 1; ipl< arr.length;ipl++)
            {
                if(!phoneList.containsKey(arr[ipl]))
                {

                    // we are creating client side index based on client secret key
                    /*
                    int ci = 0;
                    String cIndex = encryp.HMAC(arr[ipl].getBytes(),key);
                    
                    
		            for (int ici = 0; ici < cIndex.length(); ici++)
		            {       
		                int codePoint = cIndex.codePointAt(ici);
		                // Skip over the second char in a surrogate pair
		                if (codePoint > 0xffff)
		                {
		                    ici++;
		                }  
		                else
		                {
		                    ci+= codePoint;
		 
		                }    
		            } 
                    */
                    String cIndex = encryp.HMAC(arr[ipl].getBytes(),key);
                    //System.out.println("cIndex,  ci  = "+ cIndex.length() + "," + ci);
                    
                    //BigInteger ciBig = new BigInteger(Integer.toString(ci));
                    BigInteger ciBig = new BigInteger(cIndex.getBytes());
                    //miBig = decaes[now].add(miBig);
                    ciBig = ciBig.mod(_secretPrime);
                    phoneList.put(arr[ipl],ciBig.toString());
                    //
		            BigInteger inv = new BigInteger("-1");
                    BigInteger ciinv = ciBig.modPow(inv,_secretPrime);

                    //
                    //sudonamelist.put(arr[ipl],new Integer(sudonam));
                    sudonamelist.put(arr[ipl],ciinv);
                    //sudonam++;
                    
                    //System.out.println("arr[ipl] =  "+ ciBig.toString());                    
                    
                    
                    
                    
                    //
                    //phoneList.put(arr[ipl],ix.toString());
                    //ix = new BigInteger(ix.add(one).toString());
                    //
                    // compute musks
                    
                    // musking
                    //int mi = 0;
                    //String musk = encryp.HMAC(arr[ipl].getBytes(),key);
                    String musk = encryp.HMAC(arr[ipl].getBytes(),IV);// newly added: IV used for musk
                    /*
		            for (int imsk = 0; imsk < musk.length(); imsk++)
		            {       
		                int codePoint = musk.codePointAt(imsk);
		                // Skip over the second char in a surrogate pair
		                if (codePoint > 0xffff)
		                {
		                    imsk++;
		                }  
		                else
		                {
		                    mi+= codePoint;
		 
		                }    
		            }   

                    BigInteger miBig = new BigInteger(Integer.toString(mi));
                    */
                    BigInteger miBig = new BigInteger(musk.getBytes());
                    //miBig = decaes[now].add(miBig);
                    miBig = miBig.mod(_secretPrime);
                    phoneMuskList.put(arr[ipl],miBig);
                    //System.out.println("musk =  "+ miBig.toString());                    

                }
            }
            //System.out.println(line);
		}
		in.close();
	//System.out.println("sudo name list len ="+ sudonamelist.size());
       /* Set ppSet = sudonamelist.entrySet();
        Iterator ppitr = ppSet.iterator();
		while(ppitr.hasNext())
		{
            Map.Entry ele = (Map.Entry) ppitr.next();
            //
            String pnk = (String) ele.getKey();
            String pnkval = (String) sudonamelist.get(pnk).toString();
	       System.out.println( pnk + "  =  "+pnkval);
        }*/


		BigInteger q= new BigInteger("-1");
		
        /////////////////////////////////////////////////////////////////////////////////////////////////////////
        // server index generation
        // This is used to calculate the inverse of all the numbers stored in the array and store it in a 2d array
	
		HashMap<String,ServerIndexData> f_r_inverses = new HashMap<String,ServerIndexData>();//Collections.nCopies(34, sid));
		HashMap<String,ServerIndexData> f_r_inverses_new = new HashMap<String,ServerIndexData>();//Collections.nCopies(34, sid));
        
			//BigInteger one= new BigInteger("1");
        // first data in cit is 0 so first data in sit is junk
        //f_r_inverses.put("", new ServerIndexData(0.0));

        // to iterate in phone list
        Set pSet = phoneList.entrySet();
        Iterator pitr = pSet.iterator();

		while(pitr.hasNext())
		{
            Map.Entry ele = (Map.Entry) pitr.next();
            BigInteger a= new BigInteger((String)ele.getValue());
			BigInteger b= new BigInteger("1");
			b=inverse(a);
			x.add(b.intValue());
			x1.add(b.doubleValue());
            ////////////////////////////////////////////
            //f_r_inverses.put((String)ele.getKey(), new ServerIndexData(b.doubleValue())); 
            f_r_inverses.put((String)ele.getKey(), new ServerIndexData(b.toString())); 
            //
            //f_r_inverses_new.put(sudonamelist.get((String)ele.getKey()).toString(), new ServerIndexData(b.doubleValue())); 
            f_r_inverses_new.put(sudonamelist.get((String)ele.getKey()).toString(), new ServerIndexData(b.toString())); 
            //
            

		}
		//ls2d.add(x);
		//server_ind.add(x1);
        //if(f_r_inverses.size() == f_r_inverses_new.size())
        //{
          //  System.out.println("mathing starts = " + f_r_inverses.size());
        //}
        server_ind_new.add(f_r_inverses);
        server_data.add(f_r_inverses_new);
        
        /////////////////////////////////////////////////////////////////////////////////////////////////////////   
     // Preprocessing of files to be sent to cloud

        //int pos_in_file = 1;
        //int NOF = 4000;

           /* String seed1 = Long.toString(System.nanoTime());
            String sbb = seed1.getBytes();
            BigInteger pos_in_file1 = new BigInteger(sbb);
            String ss = new String(pos_in_file1.toString().getBytes());
            if(ss.equals(sbb))
            {
                System.out.println("\n hash chain should work ....");
        if(f_r_inverses.size() == f_r_inverses_new.size())


            }*/
        for (int j=1; j<=NOF; j++) //----------------------------Here the maximum limit of j denotes the number of files to be uploaded
		{
			//String part1 = null;
            //BigInteger pos_in_file = new BigInteger("0");
            String seed = Long.toString(System.nanoTime());
            BigInteger pos_in_file = new BigInteger(seed.getBytes());
            pos_in_file = pos_in_file.mod(_secretPrime);//newly added
            //String hChain = encryp.HMAC(seed.getBytes(),key);

            //BigInteger pos_in_file = new BigInteger(hChain);
            //pos_in_file = pos_in_file.mod(_secretPrime);




			//List<Integer> list1 = new ArrayList<Integer>(Collections.nCopies(34,0));//129039, 0));
            ServerIndexData sid = new ServerIndexData();
		    HashMap<String, ServerIndexData> sidl = new HashMap<String,ServerIndexData>();//Collections.nCopies(34, sid));
		    HashMap<String, ServerIndexData> sidl_new = new HashMap<String,ServerIndexData>();//Collections.nCopies(34, sid));
            //Set pSet = phoneList.entrySet();
            pitr = pSet.iterator();
            //for(int ic = 0; ic < 34;ic++)
            //{
                //sidl.add(new ServerIndexData());
            //}
            
		    while(pitr.hasNext())
		    {   
                Map.Entry ele = (Map.Entry) pitr.next();
                //
                String dd = (String)ele.getKey();
                //System.out.println("hurreeeeeyy  :  " + dd);

                //
                sidl.put((String)ele.getKey(), new ServerIndexData());
                sidl_new.put(sudonamelist.get((String)ele.getKey()).toString(), new ServerIndexData());
            }





	      ///////////////////////////////////////////////////////////////////////////////////////////////////////////////		
	     
            
			//BufferedReader fl = new BufferedReader(new FileReader("/home//indranil//Desktop//Docs//"+j+"i.txt"));
			BufferedReader fl = new BufferedReader(new FileReader("/home//indranil//Desktop//Docs//TRAIN//"+j+".txt"));
			//BufferedReader fl = new BufferedReader(new FileReader("/home//indranil//IntelligentVoice//data//"+j+".txt"));
			String line1;
            
            while((line1 = fl.readLine()) != null)
			{
                //System.out.println(line1);
				String[] arr=line1.split(",");
                ////for( int ii = 0; ii< arr.length;ii++)
                ////{
                    //String hChain = encryp.HMAC(pos_in_file.toString().getBytes(),key);  //
                    //session key seperated
                    String hChain = encryp.HMAC(pos_in_file.toString().getBytes(),key_s);
                    pos_in_file = new BigInteger(hChain.getBytes());
                    pos_in_file = pos_in_file.mod(_secretPrime);//newly added

				    String phsymb = arr[0].toLowerCase(); // 004
				    //numb=numb+1;
				    /////for(int k=0; k<phoneList.size();k++)
				    /////{
					    
					    //String part2=list.get(k)[0];
					    if(phoneList.containsKey(phsymb))
							{
						
						
					        	//int temp=(list1.get(k))+1;
						        //list1.set(k, temp);
                                //
                                List<BigInteger> lst = sidl.get(phsymb).pos;
                                List<BigInteger> lst_new = sidl_new.get(sudonamelist.get(phsymb).toString()).pos;
                                //
                                BigInteger musked = pos_in_file.add((BigInteger)phoneMuskList.get(phsymb));
                                musked = musked.mod(_secretPrime);//new change
                                BigInteger musked1 = musked.mod(_secretPrime);//new change
                                //
                                lst.add(musked);
                                lst_new.add(musked1);
                                //
                                sidl.remove(phsymb);
                                sidl.put(phsymb,new ServerIndexData(0.0,lst));
                                //
                                sidl_new.remove(sudonamelist.get(phsymb).toString());

                                sidl_new.put(sudonamelist.get(phsymb).toString(),new ServerIndexData(0.0,lst_new));


							}
				///////}
             ////}//for each word in line
			}//end of one file
            if(sidl.size() !=  sidl_new.size())
            {
                System.out.println("matching failed");
            }
            server_ind_new.add(sidl);
            server_data.add(sidl_new);
			fl.close();
		    //ls2d.add(new ArrayList<>(list1));
		
        }// iteration for all files	
		
                
        }//
		catch (Exception e) {
		      e.printStackTrace();
		} 
	}

   
   public void GuardFrequency(List<HashMap<String,ServerIndexData>> server_data)
   {
       SecureRandom r = new SecureRandom();
	   BigInteger c= new BigInteger("-1");
       List<HashMap<String,ServerIndexData>> sidnew = new ArrayList<HashMap<String,ServerIndexData>>();

       sidnew.add(server_data.get(0));
       for(int i = 1; i<server_data.size();i++)
       {
           HashMap<String,ServerIndexData> row = new HashMap<String,ServerIndexData>();
           //

           Set ppSet = server_data.get(i).entrySet();
           Iterator ppitr = ppSet.iterator();
		   while(ppitr.hasNext())
		   {
               Map.Entry ele = (Map.Entry) ppitr.next();
               //
               String pnk = (String) ele.getKey();
               //String pnkval = (String) sudonamelist.get(pnk).toString();
               ServerIndexData sido = (ServerIndexData) ele.getValue();
               List<BigInteger> lst = sido.pos;
               while(lst.size()<MAX_WORD_FRQ)
               {
                   BigInteger b = new BigInteger(160,r);
                   b =  b.modPow(c,_secretPrime);
                   lst.add(b);
                  
                 
               }

               row.put(pnk ,new ServerIndexData(0.0,lst));
               //
               
            }
            sidnew.add(row);
       }

       server_data = sidnew;

   }
}

