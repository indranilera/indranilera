import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.security.SecureRandom;
import java.math.BigInteger;

public class UtilCalculator {
    public HashMap<String,String> cit;  
	//public List<List<String>> cit;
	public List<List<Double>> server_index;
	public List<HashMap<String,ServerIndexData>> sit; 
	public List<HashMap<String,ServerIndexData>> sit_data;// this is to be sent to the server 
    public BigInteger _secretPrime;


    ///////////////////////////////////////////////////////////////////////////////////////
    // CTOR !                                                                            //
    ////////////////////i//////////////////////////////////////////////////////////////////
    //
    UtilCalculator(BigInteger prm,
	               List<HashMap<String,ServerIndexData>> server_ind_new, 
	               List<HashMap<String,ServerIndexData>> server_data// this is to be sent to the server 
    )
    {
        //_secretPrime = new BigInteger("228199");
        //SecureRandom r = new SecureRandom();
        //_secretPrime = BigInteger.probablePrime(512,r);
        _secretPrime = prm;
        sit_data =  server_data; 
        sit =  server_ind_new; 
        //System.out.println("the prime is :   " + _secretPrime.toString());
        //
        /*
        Set ssb = sit_data.get(3).entrySet();
        Iterator b = ssb.iterator();

        while(b.hasNext())    
		{
            Map.Entry mp = (Map.Entry) b.next();
            //
            String keyval = (String) mp.getKey();
            System.out.println("key string =     " + keyval);
            //
            ServerIndexData sd = (ServerIndexData) mp.getValue();
            sd.PrintData(_secretPrime);
        
        }*/



    }
    

    ///////////////////////////////////////////////////////////////////////////////////////
    // Methods ..                                                                        //
    ///////////////////////////////////////////////////////////////////////////////////////
    //
	public void BuildQuery(
    String key,
    String IV,
    String []keywords,
    List<HashMap<String,ServerIndexData>> server_ind_new, 
    List<List<String>> wordList, 
    HashMap<String,String> phoneList,  
    int num_doc,
    int tolerance
    )
    {
        //sit = server_ind_new;
        int dec_aes[]  = {0};
        BigInteger decaes[]  = {};
        List<String> dec_aes_hmac  = new ArrayList<String>();
        //List<List<String>>> phWords = new HashMap<String,List<List<String>>>();
        List<String> phWords = new ArrayList<String>();
        //String key = "";
        try
        {
		    Encryption encryp=new Encryption();
    
            // symmetric key generation :
            //Random rand=new Random();
		    //key=rand.nextSessionId();
		    //String IV=rand.nextSessionId();
    
            // forming queries using phone symbols
            for(int now = 0; now < keywords.length;now++)
            {   
                for(int ise = 0; ise<wordList.size();ise++)
                {
                    List<String> tss = new ArrayList<String>();
                    if(keywords[now].equals(wordList.get(ise).get(0)))
                    {   
                        for(int kp = 1;kp<wordList.get(ise).size();kp++)
                    
                            phWords.add(wordList.get(ise).get(kp));
                            break;
                            
                    }
                    //
                    
                }
            }
            //
            if (phWords.size()==0)
            {
                return;
            }
            //

            //System.out.println("phWords length = " + phWords.size());
            //for(int pwi = 0; pwi < phWords.size();pwi++)
            //{
            //    System.out.print( phWords.get(pwi) + "  ");
            //}
            System.out.println("-------------------------------");

            dec_aes= new int [phWords.size()];
            decaes= new BigInteger [phWords.size()];

            
            for(int now = 0; now < phWords.size();now++)
            {
                dec_aes[now] = 0;
                byte[] Enc=encryp.encrypt(IV,phWords.get(now),key);// Keysw[now], key);
		        String str=new String(Enc,"UTF-8");//US-ASCII");
                //dec_aes_hmac[now] = HMAC(Enc,key);
		        //System.out.println("The encrypted string is   :   "  +str);
		        //int encr=Integer.parseInt(Enc);
		        for (int i = 0; i < str.length(); i++)
		        {       
		            int codePoint = str.codePointAt(i);
		            // Skip over the second char in a surrogate pair
		            if (codePoint > 0xffff)
		            {
		                i++;
		            }  
		            else
		            {
		                dec_aes[now]+= codePoint;
		 
		            } 
		        }   
					
		        //dec_aes[now]%=228199;
                decaes[now] = new BigInteger(Integer.toString(dec_aes[now]));
                decaes[now] = decaes[now].mod(_secretPrime);
                //

                //dec_aes_hmac.add(encryp.HMAC(Integer.toString(dec_aes[now]).getBytes(),key));
                dec_aes_hmac.add(encryp.HMAC(decaes[now].toString().getBytes(),key));
		    //System.out.println(dec_aes[now]);
            }
            

        }
		catch (Exception e) {
		      e.printStackTrace();
		} 
    
    
        cit=phoneList;//wordList;
		List<String> traps=Trapdoor(phWords);
		BigInteger[] trapdoors = new BigInteger[phWords.size()];
        //System.out.println("size of trapdoors = "+ traps.size());
        for(int ii = 0 ; ii<traps.size();ii++)
        {
            //int TD1=Integer.parseInt(traps[ii]);
            BigInteger t1 = new BigInteger(traps.get(ii));
            BigInteger t2 = new BigInteger(Integer.toString(dec_aes[ii]));
            t1 = t2.multiply(t1);
            trapdoors[ii]=t1.mod(_secretPrime);
        }


        // Searching in encrypted domain is done here 
		if(dec_aes_hmac.size() != trapdoors.length)
        {
            return;
        }
        List<Integer> files=PartialSearch(dec_aes_hmac,key, trapdoors, trapdoors,num_doc,tolerance);
		
        System.out.println("Files are as follows:" );
        for (int nf = 0; nf < files.size();nf++)
        {
            System.out.println("["+files.get(nf).intValue()+"]");
        }
				
	}


	public void BuildMultipleQuery(
    String key,
    String IV,
    String key_s,
    String []keywords,
    //List<HashMap<String,ServerIndexData>> server_ind_new, 
    //List<HashMap<String,ServerIndexData>> server_data, 
    List<List<String>> wordList, 
    HashMap<String,String> phoneList,  
    int num_doc,
    int tolerance
    )
    {
        List<Integer> fileCollections = new ArrayList<Integer>();
        //sit = server_ind_new;
        //sit_data = server_data;
        int dec_aes[]  = {0};
        BigInteger decaes[]  = {};
        BigInteger miBig[]  = {};
        List<String> dec_aes_hmac  = new ArrayList<String>();
        //List<List<String>>> phWords = new HashMap<String,List<List<String>>>();
        List<String> phWords = new ArrayList<String>();
        HashMap<String,List<List<String>>> phWordsMap = new HashMap<String,List<List<String>>>();
        //String key = "";
        cit=phoneList;//wordList;
        try
        {
		    Encryption encryp=new Encryption();
    
            // symmetric key generation :
            //Random rand=new Random();
		    //key=rand.nextSessionId();
		    //String IV=rand.nextSessionId();
            

            // phWordsMap containing all lists against words 
            for(int now = 0; now < keywords.length;now++)
            {   
                for(int ise = 0; ise<wordList.size();ise++)
                {
                    if(keywords[now].equals(wordList.get(ise).get(0)))
                    {   
                        List<String> tstring = new ArrayList<String>();
                        for(int kp = 1;kp<wordList.get(ise).size();kp++)
                        {
                            tstring.add(wordList.get(ise).get(kp));
                            //phWordsMap.add(tstring);
                            //

                        }
                        //
                        if(phWordsMap.containsKey(keywords[now]))
                        {
                            List<List<String>> lls = (List<List<String>>) phWordsMap.get(keywords[now]);
                            lls.add(tstring);
                            phWordsMap.remove(keywords[now]);
                            phWordsMap.put(keywords[now],lls);
                        }
                        else
                        {
                            List<List<String>> lls = new ArrayList<List<String>>();//
                            lls.add(tstring);
                            phWordsMap.put(keywords[now],lls);
                        }
                        //break;    now we are playing with all combinations
                    }
                    //
                    //
                }
            }
            //
            if (phWordsMap.size()==0)
            {
                return;
            }
            //

            // forming queries using phone symbols fron phWordsMap to phWords
            
            int combData [] = new int[keywords.length];
            for(int st = 0;  st<combData.length; st++)
            {
                List<List<String>> ll = (List<List<String>>) phWordsMap.get(keywords[st]);
                combData[st]= ll.size();
                //System.out.println("------------>" + combData[st]);

            }
            
            List<List<Integer>> masterList = new ArrayList<List<Integer>>();
            List<Integer> comb = new ArrayList<Integer>();
            FormCombination(0,combData,comb,keywords.length,masterList);



	        //System.out.println("\n\t\t-------------------------------------------------------------\n");	
            //System.out.print("\n\t\tEnglish text converted into phone symbols : \t"); //combinations
            for(int pwi = 0; pwi < masterList.size();pwi++)
            {
                dec_aes_hmac  = new ArrayList<String>();
                phWords = new ArrayList<String>();
                List<Integer> posAry = masterList.get(pwi);
                //
                for(int kw = 0; kw<posAry.size();kw++)
                {
                    List<List<String>> llss = (List<List<String>>)phWordsMap.get(keywords[kw]);
                    List<String> los = llss.get(posAry.get(kw).intValue()); 
                    for(int adph = 0; adph<los.size(); adph++)
                    {
                        phWords.add(los.get(adph));
                    }
                }
                //
                // print phWord
	            System.out.println("\n\t\t-------------------------------------------------------------\n");	
                System.out.print("\n\t\tEnglish text converted into phone symbols : \t"); //combinations
                //System.out.println("\t\t\t\t\t");
	            //System.out.println("\n\t\t-------------------------------------------------------------\n");	
                for(int npwi = 0; npwi < phWords.size();npwi++)
                {
                    System.out.print(phWords.get(npwi)+ " ");
                }
	            System.out.println("\n\t\t-------------------------------------------------------------\n");	
                //System.out.println("-------------------------------");
            
                dec_aes= new int [phWords.size()];
                decaes= new BigInteger [phWords.size()];
                miBig= new BigInteger [phWords.size()];
                //             
  		        List<String> traps=Trapdoor(phWords);
		        BigInteger[] trapdoors = new BigInteger[phWords.size()];
		        BigInteger[] trapdoors_msk = new BigInteger[phWords.size()];
                //System.out.println("size of trapdoors = "+ traps.size());
                
                for(int now = 0; now < phWords.size();now++)
                {
                    dec_aes[now] = 0;
                    byte[] Enc=encryp.encrypt(IV,phWords.get(now),key);// Keysw[now], key);
		            //String str=new String(Enc,"UTF-8");//US-ASCII");
                    //dec_aes_hmac[now] = HMAC(Enc,key);
		            //System.out.println("The encrypted string is   :   "  +str);
		            //int encr=Integer.parseInt(Enc);
		            /*
                    for (int i = 0; i < str.length(); i++)
		            {       
		                int codePoint = str.codePointAt(i);
		                // Skip over the second char in a surrogate pair
		                if (codePoint > 0xffff)
		                {
		                    i++;
		                }  
		                else
		                {
		                    dec_aes[now]+= codePoint;
		 
		                }    
		            } */  
					
		            //dec_aes[now]%=228199;
                    //

                    //decaes[now] = new BigInteger(Integer.toString(dec_aes[now]));
                    decaes[now] = new BigInteger(Enc);
                    
                    decaes[now] = decaes[now].mod(_secretPrime);

                    //System.out.println("dec_aes int value = " + dec_aes[now]);
                    //System.out.println("decaes BIGInt value = " + decaes[now].toString());
                    //
                    
                    // musking
                    int mi = 0;
                    
                    //String musk = encryp.HMAC(phWords.get(now).getBytes(),key);
                    String musk = encryp.HMAC(phWords.get(now).getBytes(),IV);// newly added: IV used for musk
                    /*
		            for (int i = 0; i < musk.length(); i++)
		            {       
		                int codePoint = musk.codePointAt(i);
		                // Skip over the second char in a surrogate pair
		                if (codePoint > 0xffff)
		                {
		                    i++;
		                }  
		                else
		                {
		                    mi+= codePoint;
		 
		                }    
		            }*/   

                    //miBig[now] = new BigInteger(Integer.toString(mi));
                    miBig[now] = new BigInteger(musk.getBytes());
                    miBig[now] = miBig[now].mod(_secretPrime);
                    
                    // t2
                    BigInteger cli = new BigInteger(traps.get(now));

                    BigInteger t1 = decaes[now].multiply(cli);
                    trapdoors[now]=t1.mod(_secretPrime);


                     // t1
                    //dec_aes_hmac.add(encryp.HMAC(Integer.toString(dec_aes[now]).getBytes(),key));
                    BigInteger temp = cli.add(decaes[now]);
                    temp = temp.add(miBig[now]);
                    temp = temp.mod(_secretPrime);
                    //dec_aes_hmac.add(encryp.HMAC(temp.toString().getBytes(),key));
                    dec_aes_hmac.add(encryp.HMAC(temp.toString().getBytes(),key_s));
		            //System.out.println(dec_aes[now]);

                    //t3
                    BigInteger t3 = miBig[now].multiply(decaes[now]);
                    trapdoors_msk[now]=t3.mod(_secretPrime);

                }
            

    
    
                //cit=phoneList;//wordList;
		        //List<String> traps=Trapdoor(phWords);
		        //BigInteger[] trapdoors = new BigInteger[phWords.size()];
                //System.out.println("size of trapdoors = "+ traps.size());


                // Searching in encrypted domain is done here 
		        if(dec_aes_hmac.size() != trapdoors.length)
                {
                    return;
                }
                //System.out.println("calling partial search : ---------------------------");
                long stime = System.nanoTime();
                //List<Integer> files=PartialSearch(dec_aes_hmac,key, trapdoors,trapdoors_msk, num_doc,tolerance);
               
                List<Integer> files=null;
                if(tolerance == 1)
                {
                    files = SearchMultiword(dec_aes_hmac,key_s,trapdoors,trapdoors_msk,num_doc,tolerance);
                }
                 else{
                        files = SearchString(dec_aes_hmac,key_s,trapdoors,trapdoors_msk,num_doc,tolerance);
                
                }
                long etime = System.nanoTime();
                //
                long dur = etime - stime;
                //TimeUnit seconds = new TimeUnit();
                //System.out.println("Search_time  =  " + dur);//TimeUnit.NANOSECONDS.toSeconds(dur));
                for(int fc = 0; fc<files.size();fc++)
                {
                    fileCollections.add(files.get(fc));
                }
       //	
            } //phWords 

        }
		catch (Exception e) {
		      e.printStackTrace();
		} 

	            
        System.out.println("\n\t\t-------------------------------------------------------------\n");	

        System.out.println("\n\t\tNumber of files to be returned : " +fileCollections.size());

       
        System.out.println("\n\t\tpress any key to see the file names :" );
		Scanner reader=new Scanner(System.in);
		reader.nextLine();//Int();

        System.out.println("\n\t\tFiles are as follows:" );
			
        System.out.println("\n-----------------------------------------------------------------------------------------------------------------------------------\n");	
        
        for (int nf = 0; nf < fileCollections.size();nf++)
        {
            System.out.print("["+fileCollections.get(nf).intValue()+"]\t");
        }
        System.out.println("\n-----------------------------------------------------------------------------------------------------------------------------------\n");	
}
    
	public List<String> Trapdoor(List<String> keywords){
		
		List<String> ind=new ArrayList<String>();
		for(int ii = 0 ; ii<keywords.size();ii++)
            {
		        //ind[ii]="";
		        //for(int a=1; a<cit.size();a++)
		        //{
			        if(cit.containsKey(keywords.get(ii)))
					{
                        //System.out.println("indra's trabdoor working");
						ind.add((String) cit.get(keywords.get(ii)));
			            //int inverse=(int)sit.get(0).get(keywords.get(ii)).rs.intValue();
                        //System.out.println("indra's indexes"+ ind.get(ind.size()-));
				        //break;
					}
                    else{
                        System.out.println("phone word not in phoneList");

                    }
			//}	
		 }
		
		return(ind);
				
	}


    public void FormCombination
    (
        int index,
        int data[],
        List<Integer>comb1,
        int length,
        List<List<Integer>>masterList
    )
    {
        //System.out.println("recursion calling");
        if(index == length)
        {
            masterList.add(comb1);
            return;
        }
        else
        {
            for(int  i = 0; i<data[index];i++)
            {
                List<Integer> comb = new ArrayList<Integer>();
                //
                if(comb1.size() > 0)
                {
                    //Collections.copy(comb,comb1);
                    for(int cp = 0;cp<comb1.size();cp++)
                    {
                        comb.add(comb1.get(cp));
                    }
                }

                comb.add(new Integer(Integer.toString(i)));
                int ni = index +1;
                FormCombination(ni,data,comb,length,masterList);
            }

        }

    }

    ///////////////////////////////////////////////////////////////////
    //! Search function searches for the string in encrypted files
    //  files in cloud.
    //
	/*
    public List<Integer> ExactSearch
    (
     int[] des_aes, 
     BigInteger[] trapdoors, 
     int num_doc
    )
    {
        List<Integer> files=new ArrayList<Integer>();
        List<Integer> columns = new ArrayList<Integer>();//Collections.nCopies(trapdoors.length,-1));  
        for(int ii = 0 ; ii< trapdoors.length;ii++)
        {
		    //BigInteger  td= new BigInteger(String.valueOf(trapdoors[ii]));
		    BigInteger  da= new BigInteger(String.valueOf(des_aes[ii]));
			//System.out.println("data and trapdoors no = " + ii+"is"+ des_aes[ii]+",    "+trapdoors[ii] );
		    
            // identifying columns
            for(int b=1; b<sit.get(0).size(); b++)
		    {
			    int inverse=(int)sit.get(0).get(b).rs.intValue();
				//System.out.println("inverses and doors= "+ inverse +",   " + td);
			    BigInteger temp1=trapdoors[ii].multiply(new BigInteger(String.valueOf(inverse)));
			    BigInteger temp=temp1.mod(_secretPrime);
			    //System.out.println(temp2);k
			    //System.out.println(temp4);i
			    if(temp.equals(da))
			    {
				    //System.out.println("Yahooooooooo");
				    //System.out.println(b);
				    //
                    columns.add(new Integer(b));
                    break;
                }
            }
        }

				//System.out.println("columns size " +columns.size());
        
        //to check if there is any file containing the string.
        if(columns.size() != trapdoors.length)
        {
            System.out.println("\n  indranil why is this so\n");
        
        }
        //for(int pkk = 0 ;pkk< columns.size();pkk++)
        //System.out.println("columns :::::::::::::: "+ columns.get(pkk).intValue());
        int nWords = columns.size();
        int nFiles = sit.size() - 1;
        //List<List<Integer>> posns = new ArrayList<List<Integer>>();
        for(int ii =1;ii<= nFiles;ii++)
        {
            //System.out.println("yessssssssssssssssssssssssssssssssss");
            List<List<Integer>> posns = new ArrayList<List<Integer>>();
            boolean flag = true;
            // check if the keword exists
            for(int kw = 0; kw< nWords; kw++)
            {
                //sit.get(ii).get(columns.get(kw).intValue()).PrintData();
                if(sit.get(ii).get(columns.get(kw).intValue()).rs.intValue()>=0 )
                {
                    posns.add(new ArrayList<Integer>(sit.get(ii).get(columns.get(kw).intValue()).pos));
                }
            }
        	
            //
            if(posns.size() == trapdoors.length) // ii-th file contains all keywords
            {
                //System.out.println("all available");
                // check if they form string.
                List<Integer>finalList = new ArrayList<>();
                //boolean flag = true;
                for(int w2 =1;w2<posns.size() && flag;w2++)
                {
                    boolean w2Flg = false;
                    for(int p2 = 0; p2<posns.get(w2).size(); p2++)
                    {
                        int v2 = posns.get(w2).get(p2).intValue();
                           
                        // for the first time, find the first value v1 such that v1+1 = v2
                        if(w2 == 1)
                        {
                            boolean pfl = false;
                            for(int p1 = 0; p1<posns.get(0).size();p1++)
                            {

                                int v1 = posns.get(w2-1).get(p1).intValue();
                                int temp = v1+1;
                                if(v2 == temp)
                                {
                                    pfl = true;
                                    w2Flg = true;
                                    //System.out.println("lists ---- "+ v1 + "     "+ v2);
                                    finalList.add(v1);
                                    finalList.add(v2);
                                    break;
                                }
                                else
                                {
                                    //finalLyist.add(v1);
                                    //finalList.add(v2);
                                }
                            }
                            //flag = pfl;
                        } 
                        //
                        // for next time onwards, just check if finalvalue +1 = v2
                        else{ // w2 > 1
                            int v1 = finalList.get(finalList.size()-1).intValue();
                            int temp = v1+1;
                            if(v2 == temp)
                            {
                                w2Flg = true;
                                finalList.add(v2);
                                //System.out.println("lists ---- "+ v2);
                                break;
                            }
                            else
                            {
                                //flag = false;
                            }

                        }

                        //flag = w2Flg;

                    }// the set p2
                    flag = w2Flg;
                }//the word w2

            
            }
            else{
                   //System.out.println("why i am here");
                   flag = false;

                }
                
            if(flag)
            {
                files.add(ii);
                
		        //System.out.println("file no " + ii);
            }
        }
		//System.out.println(server_index.get(1).size());
		return files;
	}
*/	
    

    ///////////////////////////////////////////////////////////////////////////////
    // PartialSearch
    //

	public List<Integer> PartialSearch
    (
     //int [] des_aes_hmac,
     List<String> des_aes_hmac,
     String key,
     BigInteger[] trapdoors, 
     BigInteger[] trapdoors_msk, 
     int num_doc,
     int tolerance
    )
    {

        List<Integer> files=new ArrayList<Integer>();
        try{

		Encryption encryp=new Encryption();
        int countP = 0;
        int chkLength = 0;
        //List<Integer> files=new ArrayList<Integer>();
        List<String> columns = new ArrayList<String>();//Collections.nCopies(trapdoors.length,-1));  
        HashMap<String,BigInteger> musks= new HashMap<String,BigInteger>();//Collections.nCopies(trapdoors.length,-1));  
        for(int ii = 0 ; ii< trapdoors.length;ii++)
        {
		    
            // identifying columns:
            Set ssb = sit.get(0).entrySet();
            Iterator b = ssb.iterator();
            while(b.hasNext())    
		    {
                Map.Entry mp = (Map.Entry) b.next();
                ServerIndexData sd = (ServerIndexData) mp.getValue();
			    BigInteger inverse=new BigInteger(sd.inverse);
				//System.out.println("inverses and doors= "+ inverse +",   " + td);
			    
                // get clientindex
		        BigInteger inv = new BigInteger("-1");
		        BigInteger clindex =inverse.modPow(inv,_secretPrime);


                // get e
                BigInteger temp1=trapdoors[ii].multiply(inverse);
			    BigInteger temp=temp1.mod(_secretPrime);

                // get musk
		        BigInteger einv =temp.modPow(inv,_secretPrime);
                BigInteger temp2=trapdoors_msk[ii].multiply(einv);
			    temp2=temp2.mod(_secretPrime);

                //ci + msk + e
                temp = temp.add(clindex);
                temp = temp.add(temp2);
                temp = temp.mod(_secretPrime);
			    //System.out.println(temp2);k
			    //System.out.println(temp4);i
                String temp_str = temp.toString();
                String hashed  = encryp.HMAC(temp_str.getBytes(),key);

			    if(hashed.equals(des_aes_hmac.get(ii)))
			    {
				    //System.out.println("Yahooooooooo");
				    //System.out.println(b);
				    //
                    columns.add((String) mp.getKey());
                    musks.put((String)mp.getKey(),temp2);
                    break;
                }
            }
        }

        
        //to check if there is any file containing the string.
        if(columns.size() != trapdoors.length)
        {
            System.out.println("\n  indranil why is this so\n");
        }
        int nWords = columns.size();
        int nFiles = sit.size() - 1;
        double percentage = (double) tolerance/100.0; 
        for(int ii =1;ii<= nFiles;ii++)
        {
            List<List<BigInteger>> posns = new ArrayList<List<BigInteger>>();
            boolean flag = true;
            // check if the keword exists
            for(int kw = 0; kw< nWords; kw++)
            {
                if(sit.get(ii).get(columns.get(kw)).rs.intValue()>=0 )
                {
                    posns.add(new ArrayList<BigInteger>(sit.get(ii).get(columns.get(kw)).pos));
                }
            }
        	
            // if a part matches
            chkLength = (int)(trapdoors.length * percentage);
            if(posns.size() >= chkLength) // ii-th file contains a part of the phone words
            {
                // check if available phone words are ordered, i.e., forming a string.
                List<String>finalList = new ArrayList<>();
                countP = 0;
                for(int w2 =1;w2<posns.size() && flag;w2++)
                {
                    boolean w2Flg = false;
                    for(int p2 = 0; p2<posns.get(w2).size(); p2++)
                    {
                        BigInteger  mskd_v2  = posns.get(w2).get(p2);
                        BigInteger mskk = (BigInteger) musks.get(columns.get(w2));
                        BigInteger v2_big = mskd_v2.subtract(mskk);
                        //v2_big = v2_big.mod(_secretPrime);
                        //int v2 = Integer.parseInt(v2_big.toString());
                        //int v2 = posns.get(w2).get(p2).intValue();
                        String v2 = v2_big.toString();
                           
                        // for the first time, find the first value v1 such that v1+1 = v2
                        if(w2 == 1)
                        {
                            boolean pfl = false;
                            for(int p1 = 0; p1<posns.get(0).size();p1++)
                            {

                                BigInteger  mskd_v1  = posns.get(w2-1).get(p1);
                                BigInteger v1_big = mskd_v1.subtract(musks.get(columns.get(w2-1)));
                                //v1_big = v1_big.mod(_secretPrime); 
                                //int v1 = Integer.parseInt(v1_big.toString());
                                String v1 = v1_big.toString();
                                String tempA = encryp.HMAC(v1.getBytes(),key);
                                BigInteger tempB = new BigInteger(tempA.getBytes());
                                String temp = tempB.toString();
                                //int v1 = posns.get(w2-1).get(p1).intValue();
                                //int temp = v1+1;
                                if(temp.equals(v2))
                                {
                                    pfl = true;
                                    w2Flg = true;
                                    countP++;
                                    //System.out.println("lists ---- "+ v1 + "     "+ v2);
                                    finalList.add(v1);
                                    finalList.add(v2);
                                    break;
                                }
                                else
                                {
                                    //finalLyist.add(v1);
                                    //finalList.add(v2);
                                }
                            }
                            //flag = pfl;
                        } 
                        //
                        // for next time onwards, just check if finalvalue +1 = v2
                        else{ // w2 > 1
                            String v1 = finalList.get(finalList.size()-1);
                            String tempA = encryp.HMAC(v1.getBytes(),key);
                            BigInteger tempB = new BigInteger(tempA.getBytes());
                            String temp = tempB.toString();
                            //String temp = encryp.HMAC(v1.getBytes(),key);
                            //String temp = v1+1;
                            if(temp.equals(v2))//v2 == temp)
                            {
                                w2Flg = true;
                                countP++;
                                finalList.add(v2);
                                //System.out.println("lists ---- "+ v2);
                                break;
                            }
                            else
                            {
                                //flag = false;
                            }

                        }

                        //flag = w2Flg;

                    }// the set p2
                    flag = w2Flg;
                }//the word w2

            
            }
            else{
                   //System.out.println("why i am here");
                   flag = false;

                }
                
            if(flag || countP >= chkLength)
            {
                files.add(ii);
                
		        //System.out.println("file no " + ii);
            }
        }
        }
		catch (Exception e) {
		      e.printStackTrace();
		} 
		//System.out.println(server_index.get(1).size());
        if(files.size()> num_doc)
        {
		    files.subList(num_doc,files.size()).clear();
        }
        return files;
	}
	
	
    public List<Integer> SearchMultiword
    (
     //int [] des_aes_hmac,
     List<String> des_aes_hmac,
     //String key,
     String key_s,
     BigInteger[] trapdoors, 
     BigInteger[] trapdoors_msk, 
     int num_doc,
     //int tolerance,
     int multiflag
    )
    {

        List<Integer> files=new ArrayList<Integer>();
        try{

		    Encryption encryp=new Encryption();
            int countP = 0;
            int chkLength = 0;
            //List<Integer> files=new ArrayList<Integer>();
            List<String> columns = new ArrayList<String>();//Collections.nCopies(trapdoors.length,-1));  
            HashMap<String,BigInteger> musks= new HashMap<String,BigInteger>();//Collections.nCopies(trapdoors.length,-1));  
            for(int ii = 0 ; ii< trapdoors.length;ii++)
            {
		    
                // identifying columns:
                //Set ssb = sit.get(0).entrySet();
                Set ssb = sit_data.get(0).entrySet();
                Iterator b = ssb.iterator();
                while(b.hasNext())    
		        {
                    Map.Entry mp = (Map.Entry) b.next();
                    ServerIndexData sd = (ServerIndexData) mp.getValue();
			        BigInteger inverse=new BigInteger(sd.inverse);
				    //System.out.println("inverses and doors= "+ inverse +",   " + td);
			    
                    // get clientindex
		            BigInteger inv = new BigInteger("-1");
		            BigInteger clindex =inverse.modPow(inv,_secretPrime);


                    // get e
                    BigInteger temp1=trapdoors[ii].multiply(inverse);
			        BigInteger temp=temp1.mod(_secretPrime);

                    // get musk
		            BigInteger einv =temp.modPow(inv,_secretPrime);
                    BigInteger temp2=trapdoors_msk[ii].multiply(einv);
			        temp2=temp2.mod(_secretPrime);

                    //ci + msk + e
                    temp = temp.add(clindex);
                    temp = temp.add(temp2);
                    temp = temp.mod(_secretPrime);
			        //System.out.println(temp2);k
			        //System.out.println(temp4);i
                    String temp_str = temp.toString();
                    //String hashed  = encryp.HMAC(temp_str.getBytes(),key);
                    String hashed  = encryp.HMAC(temp_str.getBytes(),key_s);

			        if(hashed.equals(des_aes_hmac.get(ii)))
			        {
				        //System.out.println("Yahooooooooo");
				        //System.out.println(b);
				        //
                        String kkkk = (String) mp.getKey();
                        //System.out.println("trapdoor column name = " + kkkk);
                        columns.add((String) mp.getKey());
                        musks.put((String)mp.getKey(),temp2);
                        break;
                    }
                }
            }

        
            //to check if there is any file containing the string.
            if(columns.size() != trapdoors.length)
            {
                //System.out.println("\n  indranil why is this so\n");
            }

            int nWords = columns.size();
            int nFiles = sit.size() - 1;
            double percentage = 1;//(double) tolerance/100.0; 
            for(int ii =1;ii<= nFiles;ii++)
            {
                List<List<BigInteger>> posns = new ArrayList<List<BigInteger>>();
                boolean flag = true;
                // check if the keword exists
                for(int kw = 0; kw< nWords; kw++)
                {
                    //if(sit.get(ii).get(columns.get(kw)).rs.intValue()>=0 )
                    if(sit_data.get(ii).get(columns.get(kw)).rs.intValue()>=0 )
                    {
                        //posns.add(new ArrayList<BigInteger>(sit.get(ii).get(columns.get(kw)).pos));
                        posns.add(new ArrayList<BigInteger>(sit_data.get(ii).get(columns.get(kw)).pos));
                    }
                }
        	
                // if a part matches
                chkLength = trapdoors.length;//(int)(trapdoors.length * percentage);
                if(posns.size() == chkLength) // ii-th file contains a part of the phone words
                {
                    if(multiflag == 1)// multi keyword ( may not be ordered)
                    {
                        files.add(ii);
                        continue;
                    }


                }// end of if newly added one
                else{
                   //System.out.println("why i am here");
                   flag = false;

                }
                
            }
        }
		catch (Exception e) {
		      e.printStackTrace();
		} 
		//System.out.println(server_index.get(1).size());
        if(files.size()> num_doc)
        {
		    files.subList(num_doc,files.size()).clear();
        }
        return files;
	}
    
    public List<Integer> SearchString
    (
     //int [] des_aes_hmac,
     List<String> des_aes_hmac,
     //String key,
     String key_s,
     BigInteger[] trapdoors, 
     BigInteger[] trapdoors_msk, 
     int num_doc,
     //int tolerance,
     int multiflag
    )
    {

        List<Integer> files=new ArrayList<Integer>();
        try{

		    Encryption encryp=new Encryption();
            int countP = 0;
            int chkLength = 0;
            //List<Integer> files=new ArrayList<Integer>();
            List<String> columns = new ArrayList<String>();//Collections.nCopies(trapdoors.length,-1));  
            HashMap<String,BigInteger> musks= new HashMap<String,BigInteger>();//Collections.nCopies(trapdoors.length,-1));  
            for(int ii = 0 ; ii< trapdoors.length;ii++)
            {
		    
                // identifying columns:
                //Set ssb = sit.get(0).entrySet();
                Set ssb = sit_data.get(0).entrySet();
                Iterator b = ssb.iterator();
                while(b.hasNext())    
		        {
                    Map.Entry mp = (Map.Entry) b.next();
                    ServerIndexData sd = (ServerIndexData) mp.getValue();
			        BigInteger inverse=new BigInteger(sd.inverse);
				    //System.out.println("inverses and doors= "+ inverse +",   " + td);
			    
                    // get clientindex
		            BigInteger inv = new BigInteger("-1");
		            BigInteger clindex =inverse.modPow(inv,_secretPrime);


                    // get e
                    BigInteger temp1=trapdoors[ii].multiply(inverse);
			        BigInteger temp=temp1.mod(_secretPrime);

                    // get musk
		            BigInteger einv =temp.modPow(inv,_secretPrime);
                    BigInteger temp2=trapdoors_msk[ii].multiply(einv);
			        temp2=temp2.mod(_secretPrime);

                    //ci + msk + e
                    temp = temp.add(clindex);
                    temp = temp.add(temp2);
                    temp = temp.mod(_secretPrime);
			        //System.out.println(temp2);k
			        //System.out.println(temp4);i
                    String temp_str = temp.toString();
                    //String hashed  = encryp.HMAC(temp_str.getBytes(),key);
                    String hashed  = encryp.HMAC(temp_str.getBytes(),key_s);

			        if(hashed.equals(des_aes_hmac.get(ii)))
			        {
				        //System.out.println("Yahooooooooo");
				        //System.out.println(b);
				        //
                        String kkkk = (String) mp.getKey();
                        //System.out.println("trapdoor column name = " + kkkk);
                        columns.add((String) mp.getKey());
                        musks.put((String)mp.getKey(),temp2);
                        break;
                    }
                }
            }

        
            //to check if there is any file containing the string.
            if(columns.size() != trapdoors.length)
            {
                //System.out.println("\n  indranil why is this so\n");
            }

            int nWords = columns.size();
            //int nFiles = sit.size() - 1;
            int nFiles = sit_data.size() - 1;
            double percentage = 1;//(double) tolerance/100.0; 
            for(int ii =1;ii<= nFiles;ii++)
            {
                List<List<BigInteger>> posns = new ArrayList<List<BigInteger>>();
                boolean flag = true;
                // check if the keword exists
                for(int kw = 0; kw< nWords; kw++)
                {
                    //if(sit.get(ii).get(columns.get(kw)).rs.intValue()>=0 )
                    if(sit_data.get(ii).get(columns.get(kw)).rs.intValue()>=0 )
                    {
                        //posns.add(new ArrayList<BigInteger>(sit.get(ii).get(columns.get(kw)).pos));
                        posns.add(new ArrayList<BigInteger>(sit_data.get(ii).get(columns.get(kw)).pos));
                    }
                }
        	
                // if a part matches
                chkLength = trapdoors.length;//(int)(trapdoors.length * percentage);
                if(posns.size() == chkLength) // ii-th file contains a part of the phone words
                {
                    if(multiflag == 1)// multi keyword ( may not be ordered)
                    {
                        
                        files.add(ii);
                        continue;
                    }


                    // check if available phone words are ordered, i.e., forming a string.
                    //List<String>finalList = new ArrayList<>();
                    countP = 0;
                    int w0 = 0;// for(int w2 =1;w2<posns.size() && flag;w2++)
                    boolean w2Flg = false;
                    flag = false;
                    for(int p0 = 0; p0<posns.get(w0).size(); p0++)
                    {
                        List<String>finalList = new ArrayList<>();
                        if(flag == true)
                        {
                            break;
                        }
                        flag = false;
                        BigInteger  mskd_v0  = posns.get(w0).get(p0);
                        BigInteger mskk = (BigInteger) musks.get(columns.get(w0));
                        BigInteger v0_big = mskd_v0.subtract(mskk);
                        v0_big = v0_big.mod(_secretPrime);//newly added
                        //v2_big = v2_big.mod(_secretPrime);
                        //int v2 = Integer.parseInt(v2_big.toString());
                        //int v2 = posns.get(w2).get(p2).intValue();
                        String v0 = v0_big.toString();
                        finalList.add(v0);
                        // for the first time, find the first value v1 such that v1+1 = v2
                        for(int w1 = 1; w1 <posns.size();w1++)
                        {
                        //if(w2 == 1)
                            boolean pfl = false;
                            for(int p1 = 0; p1<posns.get(w1).size();p1++)
                            {

                                BigInteger  mskd_v1  = posns.get(w1).get(p1);
                                BigInteger v1_big = mskd_v1.subtract(musks.get(columns.get(w1)));
                                v1_big = v1_big.mod(_secretPrime);//newly added 
                                //int v1 = Integer.parseInt(v1_big.toString());
                                String v1 = v1_big.toString();
                                
                                //String tempA = encryp.HMAC(v1.getBytes(),key);
                                //BigInteger tempB = new BigInteger(tempA.getBytes());
                                //String temp = tempB.toString();
                                //int v1 = posns.get(w2-1).get(p1).intValue();
                                //int temp = v1+1;
                                ///
                                
                                String v = finalList.get(finalList.size()-1);
                                //String tempvA = encryp.HMAC(v.getBytes(),key);
                                String tempvA = encryp.HMAC(v.getBytes(),key_s);
                                BigInteger tempvB = new BigInteger(tempvA.getBytes());
                                //
                                tempvB = tempvB.mod(_secretPrime);//newly added
                                
                                String tempv = tempvB.toString();



                                ///
                                
                                
                                if(v1.equals(tempv))
                                {
                                    pfl = true;
                                    w2Flg = true;
                                    countP++;
                                    //System.out.println("lists ---- "+ v1 + "     "+ v2);
                                    finalList.add(v1);
                                    //finalList.add(v2);
                                    break;
                                }
                            }

                            if( pfl == false)
                            {
                                break;// meaning initial loop must change
                            }
                            if(finalList.size() == chkLength)
                            {
                                flag = true;
                            }
                        } 
                        //
                        // for next time onwards, just check if finalvalue +1 = v2
                        //flag = w2Flg;

                    }// the set p2

            }// end of if newly added one
            else{
                   //System.out.println("why i am here");
                   flag = false;

                }
                
            if(flag || countP >= chkLength)
            {
                files.add(ii);
                
		        //System.out.println("file no " + ii);
            }
        }
        }
		catch (Exception e) {
		      e.printStackTrace();
		} 
		//System.out.println(server_index.get(1).size());
        if(files.size()> num_doc)
        {
		    files.subList(num_doc,files.size()).clear();
        }
        return files;
	}
	
}
