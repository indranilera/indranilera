import java.security.SecureRandom;
import java.math.BigInteger;

import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
public final class Random {
  private SecureRandom random = new SecureRandom();

  public String nextSessionId() {
    return new BigInteger(80, random).toString(32);
    //return new BigInteger(160, random).toString(32);
  }
}
