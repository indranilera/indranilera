import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ServerIndex {
	public List<String[]> list;
	public List<List<Double>> server_index;

    public ServerIndex(){}
	public ServerIndex(String Keyword,List<List<Double>> server_ind, List<String[]> list1, int num_doc, int num_Decimal) {
	//	List<List<Double>> server_index = server_ind;
	//	List<String[]> client_index=list;
		list=list1;
		server_index=server_ind;
		String Trap=Trapdoor(Keyword);
		
		//System.out.println(Trap);
		int TD1=Integer.parseInt(Trap);
		
		int TD=(TD1*num_Decimal)%228199;
		//System.out.println(TD);
//		System.out.println("Shahzaib");
		List<Integer> files=Search(num_Decimal, TD, num_doc);
		//System.out.println(files);
				
		// TODO Auto-generated constructor stub
	}

	//private ArrayList<String[]> strings;
	
	public String Trapdoor(String key){
		String ind="";
		
		for(int a=1; a<list.size();a++)
		{
			
		
			String key1=list.get(a)[0];
			if(key1.equals(key))
					{
						ind = list.get(a)[1];
				
					}	
				
		}
		
		return(ind);
				
	}
	public List<Integer> Search(int Enc, int TD, int num){
		
		List<Integer> files=new ArrayList<Integer>();
		List<Double> sort=new ArrayList<Double>();
		List<Double> sort1=new ArrayList<Double>();
		int high=0;
		double max1=0;
		//System.out.println("This is num"+num);
		//System.out.println(server_index.size());
		//System.out.println(server_index.get(0).size());
		double temp2=(double)TD;
		
		
		double temp4= (double) Enc;
		for(int b=0; b<server_index.get(0).size(); b++)
		{
			
			double temp3=(double)server_index.get(0).get(b);
			double temp=(temp2*temp3)%228199;
			//System.out.println(temp2);k
			//System.out.println(temp4);
			if(temp==temp4)
			{
				System.out.println("Yahooooooooo");
				System.out.println(b);
				
				for(int s=1; s<server_index.size(); s++)
				{
					double temp6=server_index.get(s).get(b);  //indranil change1:  b+1 to b
					System.out.println(temp6);
					sort.add(temp6);
					sort1.add(temp6);
					temp6=0.0;
					
				}
				System.out.println(sort);
				Collections.sort(sort);
				System.out.println(sort);
				int maxi=sort.size();
				for(int d=1; d<=num; d++)
				{
					double current=(sort.get(maxi-d));
					if(current!=0)
					{
						
					
					for(int u=0; u<sort1.size(); u++)
					{
						if(current==sort1.get(u))
						{
							System.out.println("File "+ (u+1) +" contains the desired keyword");
							
						}
						
					}
					}
					else
					{
						
						System.out.println("File not found");
					}
					
					

					
					
				}
				/////////////////////////////////				
				/*
				for(int d=1; d<=num; d++)
				{
					for(int c=(server_index.size()-1); c>=1;c--)
					{
						double temp1=server_index.get(c).get(b);
						
						 if (temp1 >= max1) {
						        max1 = temp1;
				//		        System.out.println("Yahooooooooo1111111");
						        high=c;
						      } 
						      }
						    }
						    files.add(high);
						/*if (temp1 > max)
					     {
					      max = temp1;
					      high=c;
					     }*/
									
				
				
					}
					
					
				}
		System.out.println(server_index.get(1).size());
		return files;
			}
	
	
	
}
		
	/*	for(int a=1; a<list.size();a++)
		{
			
		
			String key1=list.get(a)[0];
			if(key1.equals(key))
					{
						ind = list.get(a)[1];
				
					}	
				
		}
		
		return(ind);
				
	}
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
/*	public void ServerIndex() throws IOException{
		
		List<String[]> list1=new ArrayList<String[]>();
//		list.add(new String[]{"hello"});//("hello");
//		list.add(new String[]{"hello1", "2", "5"});
		//list.add("Checking ");
		BufferedReader in = new BufferedReader(new FileReader("//C://Users//raj//Desktop/words.txt"));
	//	File file = new File("//C://Users//raj//Desktop/words.txt");
		String line;
		while((line = in.readLine()) != null)
		{
			//String contents=new Scanner(in).useDelimiter("\\ ").next();
			String[] arr=line.split(" ");
			list1.add(new String[]{arr[0], arr[1]});
		    //System.out.println(line);
		}
		in.close();
//		String contents = new Scanner(file).useDelimiter("\\ ").next();
//		list.add(new String[]{contents});
		
		//return (list1.get(5000)[0]);
		
	}

}*/
