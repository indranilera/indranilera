
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.*;
import java.math.*;
//import org.bouncycastle.crypto.engines.AESEngine;
//import org.apache.commons.lang.WordUtils;

//This class is used to generate a client index table when we have the keywords stored in a .txt file

public class ClientIndex {
	private ArrayList<String[]> strings;
	
	public BigInteger inverse (BigInteger A)
	{
		BigInteger c= new BigInteger("-1");
		BigInteger b= new BigInteger("228199");
	
		A=A.modPow(c,b);
	//	System.out.println(A);
		
		return A;
		
		
	}

    
	
	/*public String lookup (ArrayList <Integer> array)
	{
		
		
		
	}*/
	public ServerIndex IndexGen(String[] A, int B, int[] C) throws IOException{
	
		String Keyword=A[0];
		int num_doc=B;
		int num=C[0]; //Represents the decimal value of AES
		String ind="";
		List<String[]> list=new ArrayList<String[]>();/////////////////////////////////////////This is the client index
		ArrayList<String[]> templist=new ArrayList<String[]>();
	//	List<Integer> list1 = new ArrayList<Integer>(Collections.nCopies(150000, 0));
		List<Integer>F_d=new ArrayList<Integer>();
		List<Integer>F_t=new ArrayList<Integer>();
		int numb=0;
		
		Integer n = new Integer(100); 
		List<List<Integer>> ls2d = new ArrayList<List<Integer>>();
		
		List<List<Double>> server_ind = new ArrayList<List<Double>>();///////////////////////////////This is server index
		
        List<List<ServerIndexData>> server_ind_new = new ArrayList<List<ServerIndexData>>();///////////////////////////////This is server index
		
		
		List<Double>x1=new ArrayList<Double>();
		
		List<Integer> x = new ArrayList<Integer>();
		
        
    /////////////////////////////////////////////////////////////////////////////////////////////////
    // To read collection of all words

        BufferedReader in = new BufferedReader(new FileReader("/home//indranil//Desktop/words.txt"));
		String line;
		while((line = in.readLine()) != null)
		{
			String[] arr=line.split(" ");
			list.add(new String[]{arr[0], arr[1]});
		    //list.add(Arrays.asList(line.split(" ")));
            
            //System.out.println(line);
		}
		in.close();
	
		BigInteger q= new BigInteger("-1");
		
   /////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Client index generation
   // This is used to calculate the inverse of all the numbers stored in the array and store it in a 2d array
	
		for (int i=1;i<list.size(); i++)
		{
			
			BigInteger a= new BigInteger(list.get(i)[1]);
			BigInteger b= new BigInteger("1");
			b=inverse(a);
			x.add(b.intValue());
			x1.add(b.doubleValue());
		}
		ls2d.add(x);
		server_ind.add(x1);
        
     /////////////////////////////////////////////////////////////////////////////////////////////////////////   
     // Preprocessing of files to be sent to cloud

        //int pos_in_file = 1;
        for (int j=1; j<=3; j++) //----------------------------Here the maximum limit of j denotes the number of files to be uploaded
		{
			//String part1 = null;
            int pos_in_file = 0;
			List<Integer> list1 = new ArrayList<Integer>(Collections.nCopies(34,0));//129039, 0));
            ServerIndexData sid = new ServerIndexData();
		    List<ServerIndexData> sidl = new ArrayList<ServerIndexData>();//Collections.nCopies(34, sid));
            for(int ic = 0; ic < 34;ic++)
            {
                sidl.add(new ServerIndexData());
            }
        //System.out.println(list.size() + "\n press any key \n");
		//Scanner reader=new Scanner(System.in);
		//int s = reader.nextInt();


	///////////////////////////////////////////////////////////////////////////////////////////////////////////////		
	// Counting of frequency
            
			BufferedReader fl = new BufferedReader(new FileReader("/home//indranil//Desktop//Docs//"+j+"i.txt"));
			String line1;
            
            while((line1 = fl.readLine()) != null)
			{
                System.out.println(line1);
				String[] arr=line1.split(" ");
                for( int ii = 0; ii< arr.length;ii++)
                {
                    pos_in_file++;

				    String part1 = arr[ii].toLowerCase(); // 004
				    numb=numb+1;
				    for(int k=0; k<list.size();k++)
				    {
					    
					    String part2=list.get(k)[0];
					    if(part2.equals(part1))
							{
						
						
					        	int temp=(list1.get(k))+1;
						        list1.set(k, temp);
                                //
                                List<Integer> lst = sidl.get(k).pos;
                                lst.add(pos_in_file);
                                sidl.set(k,new ServerIndexData(0.0,lst));

							}
					else{
				//		System.out.println("not found");
					}
				}
             }//for each word in line
			}//end of one file
            server_ind_new.add(sidl);
			F_d.add(numb);
			fl.close();
		 ls2d.add(new ArrayList<>(list1));
		
        }// iteration for all files	
		
		// indranil testing
        System.out.println("..............................");
        String ap = new String("apple");


        System.out.println("fp length =  " + server_ind_new.size());
		for(int fp = 0; fp< server_ind_new.size();fp++)
        { 

            System.out.println("wp length =  " + server_ind_new.get(fp).size());
            for(int wp = 0;wp<server_ind_new.get(fp).size();wp++)
            {
                String s = list.get(wp)[0].toLowerCase();
                int l = server_ind_new.get(fp).get(wp).rs.intValue();
                //System.out.println("-----------------"+s);
                if(s.equals(ap) && l >= 0)
                {
                   List<Integer> tl = server_ind_new.get(fp).get(wp).pos;
                   System.out.print("{ ");
                   for(int ii = 0;ii<tl.size();ii++)
                       {
                           int val = tl.get(ii);
                           System.out.print(val + ", ");
                       }
                       
                   System.out.println("} ");
                }
            }

                   System.out.println("..............................");
        }
        
        
        
        System.out.println(list.size() + "\n press any key \n");
		Scanner reader=new Scanner(System.in);
		int s = reader.nextInt();
        
        
        // indranil testing
        
        
        
        
        
        /////////////////////////////////////////This part is for the relevance score generation
		//System.out.println(F_d);
		int N=ls2d.size()-1;
		int tempo=0;
		//System.out.println(ls2d.get(0).size());
		///////////////////////////////////////////////////////////
		for(int l=1; l<ls2d.get(0).size();l++)
		{
			for(int m=1; m<=N; m++)
			{
				if(ls2d.get(m).get(l)!=0)
				{
					tempo=tempo+1;
					
				}
				
				
				
			}
			F_t.add(tempo);
			
			tempo=0;
			
			
		}
	//	System.out.println(F_t);
	//	System.out.println(N);
//	System.out.println(x2);
	//System.out.println("this is first size:"+x2.size());
	
    
    //System.out.println("ls2d"+ ls2d);
		for(int p=1; p<=3;p++)
		{
			int v=1;
			List<Double> x2=new ArrayList<Double>();
			for( ;v<(ls2d.get(0).size())-1; v++)
			{
					if((ls2d.get(p).get(v-1))!=0)
					{
					//System.out.println("yes im in");
					double P0=F_t.get(v-2);
					double P1=F_d.get(p-1);
					double P2=(ls2d.get(p).get(v-1).doubleValue());
					double P3=P2;///////////////Math.log
					double P4=1+P3;
					double P5=1/P1;
					double P6=N/P0;
					double P7=1+P6;
					double P8=P7;/////////////
					double RF=P5*P4*P8*100;
				    //System.out.println(RF);
				    x2.add(RF);
				    RF=0.0;
			          }
			//	}
					else{
						x2.add(0.0);
					}
					
				}
			
			server_ind.add(new ArrayList<>(x2));
		//	x2.clear();
		}
		
	//	System.out.println(server_ind);
		//System.out.println(F_d.size());
		
		////////////////////////////////////////////////////////////////////////////////////////////////This is for the Trapdoor generation
		for(int a=1; a<list.size();a++)
		{
			
		//	System.out.println("1---------"+part1);
	//		System.out.println(list.get(k)[0]);
			String key1=list.get(a)[0];
			if(key1.equals(Keyword))
					{
				ind=list.get(a)[1];
				
					}
				
				
	//			System.out.println("its a match");
			//	System.out.println(k)
		//		System.out.println(list1.get(k)+"-------------------");
		//		break outerloop;
				
				
		}
		//server.IndexGen(server_ind);
	
		//return ();
		//return(ind);

        
		//return new ServerIndex();
		return new ServerIndex(Keyword, server_ind,list, num_doc,num);
		
		
	}
}

