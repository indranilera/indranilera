import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.apache.commons.lang3.StringUtils;

public class Main {

	public static void main(String[] args) throws IOException {
		
	// TODO Auto-generated method stub
		int Trapdoor;
		ClientIndex client=new ClientIndex();
		
		
	//ServerIndex server=new ServerIndex();
		Encryption encryp=new Encryption();
		
		
    //////////////////////////////////////////////////////////////////////////////////////
	//  Input section: 
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter the string to be searched:");
		String keywordstr=reader.nextLine();
        String keywords [] = keywordstr.split(" ");
        String Keysw[] = new String[keywords.length];
        for(int i = 0; i< keywords.length;i++)
        {
		    Keysw[i] = org.apache.commons.lang3.StringUtils.leftPad(keywords[i], 16,"\0");
		    System.out.println(Keysw[i]);
        }

    //		int val=reader.nextInt();
		System.out.println("Enter the desired number of documents:");
		int num_doc=reader.nextInt();
		
   
    ///////////////////////////////////////////////////////////////////////////////////////
    // symmetric key generation :
        Random rand=new Random();
		String key=rand.nextSessionId();
		String IV=rand.nextSessionId();
		
    //////////////////////////////////////////////////////////////////////////////////////
    // finding Decimal(AES(keyword)) in the variable num :
        int num[]= new int[keywords.length];
		try{
            for(int now = 0; now < keywords.length;now++)
            {   num[now] = 0;
                byte[] Enc=encryp.encrypt(IV, Keysw[now], key);
		        String str=new String(Enc,"US-ASCII");
		
		        System.out.println("The encrypted string is   :   "  +str);
		//int encr=Integer.parseInt(Enc);
		        for (int i = 0; i < str.length(); i++)
		        {       
		            int codePoint = str.codePointAt(i);
		            // Skip over the second char in a surrogate pair
		            if (codePoint > 0xffff)
		            {
		                i++;
		            }
		            else
		            {
		                num[now]+= codePoint;
		    
		            }
		        }   
					
		        num[now]%=228199;
		        System.out.println(num[now]);
             }
        /*
		String Dec=encryp.decrypt(IV, Enc, key);
		System.out.println(Dec);
        */
     
     ///////////////////////////////////////////////////////////////////////////////////////
     // client index generation 
		//System.out.println("num = " + num + " ..............\n");
        System.out.println(client.IndexGen(keywords, num_doc,num));
		}
		catch (Exception e) {
		      e.printStackTrace();
		    } 

	}

}
