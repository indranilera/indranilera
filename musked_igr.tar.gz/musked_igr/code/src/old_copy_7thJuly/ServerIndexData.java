
import java.util.ArrayList;
import java.util.List;
public class ServerIndexData{

 Double rs;
 List<Integer>pos;

 public ServerIndexData()
 {
    rs = new Double(-1.0);
    pos = new ArrayList<Integer>();
 }

 public ServerIndexData(double a, List<Integer> l)
 {
     rs = new Double(a);
     pos = l;
 }

 public void PrintData()
 {
     System.out.print("rs = "+ rs.intValue());
     System.out.print(",  list :  <");
     for(int i = 0;i < pos.size();i++)
     {
     System.out.print(", "+ pos.get(i));

     }

     System.out.print(">\n");
     return ;
 }
}
