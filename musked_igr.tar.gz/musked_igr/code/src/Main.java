import java.io.FileNotFoundException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Scanner;
import org.apache.commons.lang3.StringUtils;
import java.util.HashMap;
import java.math.BigInteger;//util.HashMap;
import java.security.SecureRandom;
public class Main {

	public static void main(String[] args) throws IOException {
		
	    // TODO Auto-generated method stub
		int Trapdoor;
        long stime = 0;
        long etime = 0;
        long dur = 0;
		//Index client=new Index();
        SecureRandom r = new SecureRandom();
        //BigInteger prm = BigInteger.probablePrime(129,r);
        BigInteger prm = BigInteger.probablePrime(161,r);
        //System.out.println("first time the prime is :   " + prm.toString());
		//Index client=new Index(prm);
		
	    //ServerIndex server=new ServerIndex();
		Encryption encryp=new Encryption();
		
        //////////////////////////////////////////////////////////////////////////////////////
	    //  Input section: 
		Scanner reader=new Scanner(System.in);
		//System.out.println("Enter no of documents:");
		//int nof= reader.nextInt();
		final String ANSI_CLS = "\u001b[2J";
        final String ANSI_HOME = "\u001b[H";
        System.out.print(ANSI_CLS + ANSI_HOME);
        System.out.flush();
        System.out.println("\n\t\t-------------------------------------------------------------\n");	
		System.out.println("\t \t Enter the string to be searched: \t");
		String keywordstr=reader.nextLine();
	    System.out.println("\n\t\t-------------------------------------------------------------\n");	
        String keywords [] = keywordstr.split(" ");
        String Keysw[] = new String[keywords.length];
        for(int i = 0; i< keywords.length;i++)
        {
		    Keysw[i] = org.apache.commons.lang3.StringUtils.leftPad(keywords[i], 16,"\0");
        }

		//System.out.println("Enter the desired number of documents:");
		//int num_doc=reader.nextInt();
	
	    System.out.println("\n\t\t-------------------------------------------------------------\n");	
		System.out.println("\t\tEnter no of documents: ");
		//System.out.println("\n\t\t-------------------------------------------------------------\n");	
		int nof= reader.nextInt();
		System.out.println("\n\t\t-------------------------------------------------------------\n");	
        // tolerance = 100 means by default it will search for 
		int num_doc=nof;
        //the exact string with 100% match
        //
		System.out.println("\t\tEnter mode of search :\n \t\t  1 -> Multikeyword search \n\t\t 2 -> String search");
        int tolerance = reader.nextInt();
        //if(args.length == 1)
        //{
        //    tolerance = Integer.parseInt(args[0]);
        //}
		
        
        Index client=new Index(prm,nof);
     
        try{

            // KeyGen()
            //java.security.SecureRandom.
            
            //Encryption key 
            Random rand=new Random();
		    String key=rand.nextSessionId();
            //int  lll = key.getBytes().length;
            //System.out.println("key length = " + lll);
		    String IV=rand.nextSessionId();
            
            // session key key_s
            String key_s=rand.nextSessionId();

            System.out.println("key =  " + key + "\nkey_s= " + key_s); 
            //
            List<List<String>> wordList=new ArrayList<List<String>>();/////////////////////////////////////////This is the client index
            
            // this is secret to client
            HashMap<String,String> phoneList = new HashMap<String, String>();  
            
            // this is also secret to client
            List<HashMap<String,ServerIndexData>> server_ind_new = new ArrayList<HashMap<String,ServerIndexData>>(); // server index
            
            // this is to be sent to server
            List<HashMap<String,ServerIndexData>> server_data = new ArrayList<HashMap<String,ServerIndexData>>(); // server index
            
            // BuildIndex()
            stime = System.nanoTime();
            client.IndexGen(wordList,phoneList,server_ind_new,server_data,key,IV,key_s);
            client.GuardFrequency(server_data);
            etime = System.nanoTime();
            //
            dur = etime - stime;
            //TimeUnit seconds = new TimeUnit();

            System.out.println("BuildIndex_time  =  " +dur);//TimeUnit.NANOSECONDS.toSeconds(dur));
            
            //System.out.println("wordList  length =  " + wordList.size());
            //System.out.println("phoneList length =  " + phoneList.size());
            //System.out.println("sit " + server_ind_new.get(0).size());

            //client.IndexGen(keywords, num_doc,num,list,server_ind_new);
   
            ///////////////////////////////////////////////////////////////////////////////////
		    // indranil testing
            /* 
            System.out.println(".............................."+ server_ind_new.size());
            String ap = new String("apple");


            System.out.println("fp length =  " + server_ind_new.size());
		    for(int fp = 1; fp< server_ind_new.size();fp++)
            { 

                System.out.println("wp length =  " + server_ind_new.get(fp).size());
                for(int wp = 0;wp<server_ind_new.get(fp).size();wp++)
                {
                    String s = list.get(wp)[0].toLowerCase();
                    int l = server_ind_new.get(fp).get(wp).rs.intValue();
                    //System.out.println("-----------------"+s);
                    if(s.equals(ap) && l >= 0)
                    {
                        List<Integer> tl = server_ind_new.get(fp).get(wp).pos;
                        System.out.print("{ ");
                        for(int ii = 0;ii<tl.size();ii++)
                        {
                            int val = tl.get(ii);
                            System.out.print(val + ", ");
                        }
                       
                        System.out.println("} ");
                    }
                }

                System.out.println("..............................");
            }*/
            //indranil testing
        
        
            //. Forming search query
            UtilCalculator calc = new UtilCalculator(prm,server_ind_new,server_data);
        
		    //calc.BuildMultipleQuery(key,IV,key_s,keywords, server_ind_new, server_data,wordList,phoneList, num_doc,tolerance);
		    calc.BuildMultipleQuery(key,IV,key_s,keywords, wordList,phoneList, num_doc,tolerance);

        
            //System.out.println(list.size() + "\n press any key \n");
		    //Scanner reader=new Scanner(System.in);
		    //int s = reader.nextInt();
        
        
            // indranil testing
        }
		catch (Exception e) {
		      e.printStackTrace();
		} 

	}


}
